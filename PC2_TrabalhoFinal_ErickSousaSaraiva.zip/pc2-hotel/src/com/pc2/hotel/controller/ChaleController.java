package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Chale;
import com.pc2.hotel.persistence.ChaleDAO;

public class ChaleController {
	private ChaleDAO chaleDAO;
	public ChaleController(ChaleDAO chaleDAO) {
		this.chaleDAO = chaleDAO;
	}
	public String inserir(Chale chale) {
		return chaleDAO.inserir(chale);
	}
	public String alterar(Chale chale) {
		return chaleDAO.alterar(chale);
	}
	public String excluir(Chale chale) {
		return chaleDAO.excluir(chale);
	}
	public List<Chale> listarTodos() {
		return chaleDAO.listarTodos();
	}
	public Chale pesquisarPorId(int id) {
		return chaleDAO.pesquisarPorId(id);
	}
	public double calcularValorFinal(double valorBaixaEstacao, double valorAltaEstacao, int qtdPessoas) {
	        return chaleDAO.valorFinal(valorBaixaEstacao, valorAltaEstacao, qtdPessoas);
	}
}

package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.HospedagemServico;
import com.pc2.hotel.persistence.HospedagemServicoDAO;

public class HospedagemServicoController {
	private HospedagemServicoDAO hospedagemServicoDAO;
	public HospedagemServicoController(HospedagemServicoDAO hospedagemServicoDAO) {
		this.hospedagemServicoDAO = hospedagemServicoDAO;
	}
	public String inserir(HospedagemServico hospedagemServico) {
		return hospedagemServicoDAO.inserir(hospedagemServico);
	}
	public String alterar(HospedagemServico hospedagemServico) {
		return hospedagemServicoDAO.alterar(hospedagemServico);
	}
	public String excluir(HospedagemServico hospedagemServico) {
		return hospedagemServicoDAO.excluir(hospedagemServico);
	}
	public List<HospedagemServico> listarTodos(){
		return hospedagemServicoDAO.listarTodos();
	}
	public HospedagemServico pesquisarPorId(int codHospedagem, int codServico) {
		return hospedagemServicoDAO.pesquisarPorId(codHospedagem, codServico);
	}
}

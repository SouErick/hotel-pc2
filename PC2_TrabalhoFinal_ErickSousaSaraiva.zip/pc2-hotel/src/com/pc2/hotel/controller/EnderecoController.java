package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Endereco;
import com.pc2.hotel.persistence.EnderecoDAO;

public class EnderecoController {
	private EnderecoDAO enderecoDAO;
	public EnderecoController(EnderecoDAO enderecoDAO) {
		this.enderecoDAO = enderecoDAO;
	}
    public String inserir(Endereco endereco) {
    	return enderecoDAO.inserir(endereco);
    }
    public String alterar(Endereco endereco) {
    	return enderecoDAO.alterar(endereco);
    }
    public String excluir(Endereco endereco) {
    	return enderecoDAO.excluir(endereco);
    }
    public List<Endereco> listarTodos(){
    	return enderecoDAO.listarTodos();
    }
    public Endereco pesquisarPorId(int id) {
    	return enderecoDAO.pesquisarPorId(id);
    }
	
}

package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Servico;
import com.pc2.hotel.persistence.ServicoDAO;

public class ServicoController {
	private ServicoDAO servicoDAO;
    public ServicoController(ServicoDAO servicoDAO) {
		this.servicoDAO = servicoDAO;
	}
	public String inserir(Servico servico) {
		return servicoDAO.inserir(servico);
	}
    public String alterar(Servico servico) {
    	return servicoDAO.alterar(servico);
    }
    public String excluir(Servico servico) {
    	return servicoDAO.excluir(servico);
    }
    public List<Servico> listarTodos(){
    	return servicoDAO.listarTodos();
    }
    public Servico pesquisarPorId(int id) {
    	return servicoDAO.pesquisarPorId(id);
    }
}

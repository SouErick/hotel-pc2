package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.ChaleItem;
import com.pc2.hotel.persistence.ChaleItemDAO;

public class ChaleItemController {
	private ChaleItemDAO chaleItemDAO;
	public ChaleItemController(ChaleItemDAO chaleItemDAO) {
		this.chaleItemDAO = chaleItemDAO;
	}
	public String inserir(ChaleItem chaleItem) {
		return chaleItemDAO.inserir(chaleItem);
	}
	public String alterar(ChaleItem chaleItem) {
		return chaleItemDAO.alterar(chaleItem);
	}
    public String excluir(ChaleItem chaleItem) {
    	return chaleItemDAO.excluir(chaleItem);
    }
    public List<ChaleItem> listarTodos(){
    	return chaleItemDAO.listarTodos();
    }
    public ChaleItem pesquisarPorId(int codChale, String nomeItem) {
    	return chaleItemDAO.pesquisarPorId(codChale, nomeItem);
    }
}

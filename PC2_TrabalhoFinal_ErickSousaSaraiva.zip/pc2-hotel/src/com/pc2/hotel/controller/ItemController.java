package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Item;
import com.pc2.hotel.persistence.ItemDAO;

public class ItemController {
	private ItemDAO itemDAO;
	public ItemController(ItemDAO itemDAO) {
		this.itemDAO = itemDAO;
	}
    public String inserir(Item item) {
    	return itemDAO.inserir(item);
    }
    public String alterar(Item item) {
    	return itemDAO.alterar(item);
    }
    public String excluir(Item item) {
    	return itemDAO.excluir(item);
    }
    public List<Item> listarTodos(){
    	return itemDAO.listarTodos();
    }
    public Item pesquisarPorId(String nomeItem) {
    	return itemDAO.pesquisarPorId(nomeItem);
    }
}

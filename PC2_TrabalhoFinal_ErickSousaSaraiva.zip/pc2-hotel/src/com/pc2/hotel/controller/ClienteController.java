package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Cliente;
import com.pc2.hotel.persistence.ClienteDAO;

public class ClienteController {
    private ClienteDAO clienteDAO;
    public ClienteController(ClienteDAO clienteDAO) {
        this.clienteDAO = clienteDAO;
    }
    public String inserirCliente(Cliente cliente) {
        return clienteDAO.inserir(cliente);
    }
    public String alterarCliente(Cliente cliente) {
        return clienteDAO.alterar(cliente);
    }
    public String excluirCliente(Cliente cliente) {
        return clienteDAO.excluir(cliente);
    }
    public List<Cliente> listarTodosClientes() {
        return clienteDAO.listarTodos();
    }
    public Cliente pesquisarClientePorId(int id) {
        return clienteDAO.pesquisarPorId(id);
    }
}

package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Hospedagem;
import com.pc2.hotel.persistence.HospedagemDAO;

public class HospedagemController {
	private HospedagemDAO hospedagemDAO;
    public HospedagemController(HospedagemDAO hospedagemDAO) {
        this.hospedagemDAO = hospedagemDAO;
    }
    public String inserir(Hospedagem hospedagem) {
    	return hospedagemDAO.inserir(hospedagem);
    }
    public String alterar(Hospedagem hospedagem) {
    	return hospedagemDAO.alterar(hospedagem);
    }
    public String excluir(Hospedagem hospedagem) {
    	return hospedagemDAO.excluir(hospedagem);
    }
    public List<Hospedagem> listarTodos(){
    	return hospedagemDAO.listarTodos();
    }
    public Hospedagem pesquisarPorId(int id) {
    	return hospedagemDAO.pesquisarPorId(id);
    }
}

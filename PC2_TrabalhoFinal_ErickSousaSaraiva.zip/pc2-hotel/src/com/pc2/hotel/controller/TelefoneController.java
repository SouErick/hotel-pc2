package com.pc2.hotel.controller;

import java.util.List;

import com.pc2.hotel.model.Telefone;
import com.pc2.hotel.persistence.TelefoneDAO;

public class TelefoneController {
	private TelefoneDAO telefoneDAO;
    public TelefoneController(TelefoneDAO telefoneDAO) {
		this.telefoneDAO = telefoneDAO;
	}
	public String inserir(Telefone telefone) {
		return telefoneDAO.inserir(telefone);
    }
    public String alterar(Telefone telefone) {
    	return telefoneDAO.alterar(telefone);
    }
    public String excluir(Telefone telefone) {
    	return telefoneDAO.excluir(telefone);
    }
    public List<Telefone> listarTodos(){
    	return telefoneDAO.listarTodos();
    }
    public Telefone pesquisarPorId(int id) {
    	return telefoneDAO.pesquisarPorId(id);
    }
}

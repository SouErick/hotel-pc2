package com.pc2.hotel.model;

public class Cliente {
	private int codCliente;
	private String nomeCliente;
	private String rgCliente;
	private String nascimentoCliente;
	public Cliente() {
	}
	public int getCodCliente() {
		return codCliente;
	}
	public void setCodCliente(int codCliente) {
		this.codCliente = codCliente;
	}
	public String getNomeCliente() {
		return nomeCliente;
	}
	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	public String getRgCliente() {
		return rgCliente;
	}
	public void setRgCliente(String rgCliente) {
		this.rgCliente = rgCliente;
	}
	public String getNascimentoCliente() {
		return nascimentoCliente;
	}
	public void setNascimentoCliente(String nascimentoCliente) {
		this.nascimentoCliente = nascimentoCliente;
	}
	@Override
	public String toString() {
		return "Cliente [codCliente=" + codCliente + ", nomeCliente=" + nomeCliente + ", rgCliente=" + rgCliente
				+ ", nascimentoCliente=" + nascimentoCliente + "]";
	}
}

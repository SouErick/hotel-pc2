package com.pc2.hotel.model;

public class HospedagemServico {
	private int codHospedagem;
    private String dataServico;
    private int codServico;
    private double valorServico;
    public HospedagemServico() {
    }
    public int getCodHospedagem() {
        return codHospedagem;
    }
    public void setCodHospedagem(int codHospedagem) {
        this.codHospedagem = codHospedagem;
    }
    public String getDataServico() {
        return dataServico;
    }
    public void setDataServico(String dataServico) {
        this.dataServico = dataServico;
    }
    public int getCodServico() {
        return codServico;
    }
    public void setCodServico(int codServico) {
        this.codServico = codServico;
    }
    public double getValorServico() {
        return valorServico;
    }
    public void setValorServico(double valorServico) {
        this.valorServico = valorServico;
    }
}

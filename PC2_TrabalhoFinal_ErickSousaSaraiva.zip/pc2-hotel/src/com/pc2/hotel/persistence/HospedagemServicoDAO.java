package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.HospedagemServico;

public interface HospedagemServicoDAO {
    public String inserir(HospedagemServico hospedagemServico);
    public String alterar(HospedagemServico hospedagemServico);
    public String excluir(HospedagemServico hospedagemServico);
    public List<HospedagemServico> listarTodos();
    public HospedagemServico pesquisarPorId(int codHospedagem, int codServico);
}

package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.Endereco;

public interface EnderecoDAO {
    public String inserir(Endereco endereco);
    public String alterar(Endereco endereco);
    public String excluir(Endereco endereco);
    public List<Endereco> listarTodos();
    public Endereco pesquisarPorId(int id);
}
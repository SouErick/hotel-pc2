package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Endereco;
import com.pc2.hotel.persistence.EnderecoDAO;

public class EnderecoDAOImpl implements EnderecoDAO {
    private Connection connection;
    public EnderecoDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(Endereco endereco) {
        String sql = "INSERT INTO ENDERECO (enderecoCliente, bairroCliente, estadoCliente, CEPCliente, codCliente) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, endereco.getEnderecoCliente());
            ps.setString(2, endereco.getBairroCliente());
            ps.setString(3, endereco.getEstadoCliente());
            ps.setString(4, endereco.getCepCliente());
            ps.setInt(5, endereco.getCodCliente());
            ps.executeUpdate();
            return "Endereço inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir endereço: " + e.getMessage();
        }
    }
    @Override
    public String alterar(Endereco endereco) {
        String sql = "UPDATE ENDERECO SET enderecoCliente = ?, bairroCliente = ?, estadoCliente = ?, CEPCliente = ?, codCliente = ? WHERE codEndereco = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, endereco.getEnderecoCliente());
            ps.setString(2, endereco.getBairroCliente());
            ps.setString(3, endereco.getEstadoCliente());
            ps.setString(4, endereco.getCepCliente());
            ps.setInt(5, endereco.getCodCliente());
            ps.setInt(6, endereco.getCodEndereco());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "Endereço atualizado com sucesso!";
            } else {
                return "Erro ao atualizar endereço!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar endereço: " + e.getMessage();
        }
    }
    @Override
    public String excluir(Endereco endereco) {
        String sql = "DELETE FROM ENDERECO WHERE codEndereco = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, endereco.getCodEndereco());
            ps.executeUpdate();
            return "Endereço excluído com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir endereço: " + e.getMessage();
        }
    }
    @Override
    public List<Endereco> listarTodos() {
        List<Endereco> enderecos = new ArrayList<>();
        String sql = "SELECT * FROM ENDERECO";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Endereco endereco = new Endereco();
                endereco.setCodEndereco(rs.getInt("codEndereco"));
                endereco.setEnderecoCliente(rs.getString("enderecoCliente"));
                endereco.setBairroCliente(rs.getString("bairroCliente"));
                endereco.setEstadoCliente(rs.getString("estadoCliente"));
                endereco.setCepCliente(rs.getString("CEPCliente"));
                endereco.setCodCliente(rs.getInt("codCliente"));
                enderecos.add(endereco);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return enderecos;
    }

    @Override
    public Endereco pesquisarPorId(int id) {
        Endereco endereco = null;
        String sql = "SELECT * FROM ENDERECO WHERE codEndereco = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    endereco = new Endereco();
                    endereco.setCodEndereco(rs.getInt("codEndereco"));
                    endereco.setEnderecoCliente(rs.getString("enderecoCliente"));
                    endereco.setBairroCliente(rs.getString("bairroCliente"));
                    endereco.setEstadoCliente(rs.getString("estadoCliente"));
                    endereco.setCepCliente(rs.getString("CEPCliente"));
                    endereco.setCodCliente(rs.getInt("codCliente"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return endereco;
    }
}

package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Telefone;
import com.pc2.hotel.persistence.TelefoneDAO;

public class TelefoneDAOImpl implements TelefoneDAO {
    private Connection connection;
    public TelefoneDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(Telefone telefone) {
        String sql = "INSERT INTO TELEFONE (telefone, tipoTelefone, codCliente) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, telefone.getTelefone());
            ps.setString(2, telefone.getTipoTelefone());
            ps.setInt(3, telefone.getCodCliente());
            ps.executeUpdate();
            return "Telefone inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir telefone: " + e.getMessage();
        }
    }
    @Override
    public String alterar(Telefone telefone) {
        String sql = "UPDATE TELEFONE SET telefone = ?, tipoTelefone = ?, codCliente = ? WHERE idTelefone = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, telefone.getTelefone());
            ps.setString(2, telefone.getTipoTelefone());
            ps.setInt(3, telefone.getCodCliente());
            ps.setInt(4, telefone.getIdTelefone());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "Telefone atualizado com sucesso!";
            } else {
                return "Erro ao atualizar telefone!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar telefone: " + e.getMessage();
        }
    }
    @Override
    public String excluir(Telefone telefone) {
        String sql = "DELETE FROM TELEFONE WHERE idTelefone = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, telefone.getIdTelefone());
            ps.executeUpdate();
            return "Telefone excluído com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir telefone: " + e.getMessage();
        }
    }
    @Override
    public List<Telefone> listarTodos() {
        List<Telefone> telefones = new ArrayList<>();
        String sql = "SELECT * FROM TELEFONE";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Telefone telefone = new Telefone();
                telefone.setIdTelefone(rs.getInt("idTelefone"));
                telefone.setTelefone(rs.getString("telefone"));
                telefone.setTipoTelefone(rs.getString("tipoTelefone"));
                telefone.setCodCliente(rs.getInt("codCliente"));
                telefones.add(telefone);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return telefones;
    }
    @Override
    public Telefone pesquisarPorId(int id) {
        Telefone telefone = null;
        String sql = "SELECT * FROM TELEFONE WHERE idTelefone = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    telefone = new Telefone();
                    telefone.setIdTelefone(rs.getInt("idTelefone"));
                    telefone.setTelefone(rs.getString("telefone"));
                    telefone.setTipoTelefone(rs.getString("tipoTelefone"));
                    telefone.setCodCliente(rs.getInt("codCliente"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return telefone;
    }
}

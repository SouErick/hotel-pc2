package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Hospedagem;
import com.pc2.hotel.persistence.HospedagemDAO;

public class HospedagemDAOImpl implements HospedagemDAO {
    private Connection connection;
    public HospedagemDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(Hospedagem hospedagem) {
        String sql = "INSERT INTO HOSPEDAGEM (estado, dataInicio, dataFim, qtdPessoas, desconto, valorFinal, codChale, codCliente) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, hospedagem.getEstado());
            ps.setString(2, hospedagem.getDataInicio());
            ps.setString(3, hospedagem.getDataFim());
            ps.setInt(4, hospedagem.getQtdPessoas());
            ps.setDouble(5, hospedagem.getDesconto());
            ps.setDouble(6, hospedagem.getValorFinal());
            ps.setInt(7, hospedagem.getCodChale());
            ps.setInt(8, hospedagem.getCodCliente());
            ps.executeUpdate();
            return "Hospedagem inserida com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir hospedagem: " + e.getMessage();
        }
    }
    @Override
    public String alterar(Hospedagem hospedagem) {
        String sql = "UPDATE HOSPEDAGEM SET estado = ?, dataInicio = ?, dataFim = ?, qtdPessoas = ?, desconto = ?, valorFinal = ?, codChale = ?, codCliente = ? WHERE codHospedagem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, hospedagem.getEstado());
            ps.setString(2, hospedagem.getDataInicio());
            ps.setString(3, hospedagem.getDataFim());
            ps.setInt(4, hospedagem.getQtdPessoas());
            ps.setDouble(5, hospedagem.getDesconto());
            ps.setDouble(6, hospedagem.getValorFinal());
            ps.setInt(7, hospedagem.getCodChale());
            ps.setInt(8, hospedagem.getCodCliente());
            ps.setInt(9, hospedagem.getCodHospedagem());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0 ? "Hospedagem atualizada com sucesso!" : "Erro ao atualizar hospedagem!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar hospedagem: " + e.getMessage();
        }
    }
    @Override
    public String excluir(Hospedagem hospedagem) {
        String sql = "DELETE FROM HOSPEDAGEM WHERE codHospedagem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, hospedagem.getCodHospedagem());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0 ? "Hospedagem excluída com sucesso!" : "Erro ao excluir hospedagem!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir hospedagem: " + e.getMessage();
        }
    }
    @Override
    public List<Hospedagem> listarTodos() {
        List<Hospedagem> hospedagens = new ArrayList<>();
        String sql = "SELECT * FROM HOSPEDAGEM";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Hospedagem hospedagem = new Hospedagem();
                hospedagem.setCodHospedagem(rs.getInt("codHospedagem"));
                hospedagem.setEstado(rs.getString("estado"));
                hospedagem.setDataInicio(rs.getString("dataInicio"));
                hospedagem.setDataFim(rs.getString("dataFim"));
                hospedagem.setQtdPessoas(rs.getInt("qtdPessoas"));
                hospedagem.setDesconto(rs.getDouble("desconto"));
                hospedagem.setValorFinal(rs.getDouble("valorFinal"));
                hospedagem.setCodChale(rs.getInt("codChale"));
                hospedagem.setCodCliente(rs.getInt("codCliente"));
                hospedagens.add(hospedagem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hospedagens;
    }
    @Override
    public Hospedagem pesquisarPorId(int id) {
        Hospedagem hospedagem = null;
        String sql = "SELECT * FROM HOSPEDAGEM WHERE codHospedagem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    hospedagem = new Hospedagem();
                    hospedagem.setCodHospedagem(rs.getInt("codHospedagem"));
                    hospedagem.setEstado(rs.getString("estado"));
                    hospedagem.setDataInicio(rs.getString("dataInicio"));
                    hospedagem.setDataFim(rs.getString("dataFim"));
                    hospedagem.setQtdPessoas(rs.getInt("qtdPessoas"));
                    hospedagem.setDesconto(rs.getDouble("desconto"));
                    hospedagem.setValorFinal(rs.getDouble("valorFinal"));
                    hospedagem.setCodChale(rs.getInt("codChale"));
                    hospedagem.setCodCliente(rs.getInt("codCliente"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hospedagem;
    }
}

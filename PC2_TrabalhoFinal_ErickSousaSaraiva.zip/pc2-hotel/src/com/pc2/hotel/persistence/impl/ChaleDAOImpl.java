package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Chale;
import com.pc2.hotel.persistence.ChaleDAO;

public class ChaleDAOImpl implements ChaleDAO {
	Connection connection;
	public ChaleDAOImpl(Connection connection) {
		this.connection = connection;
	}
	@Override
	public String inserir(Chale chale) {
		String sql = "INSERT INTO CHALE(localizacao, capacidade, valorAltaEstacao, valorBaixaEstacao)"
				+ " VALUES(?, ?, ?, ?)";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, chale.getLocalizacao());
			ps.setInt(2, chale.getCapacidade());
			ps.setDouble(3, chale.getValorAltaEstacao());
			ps.setDouble(4, chale.getValorBaixaEstacao());
			ps.executeUpdate();
			return "Insercao concluida";

		} catch (SQLException e) {
			e.printStackTrace();
			return "Erro ao inserir: " + e.getMessage();
		}
	}
	@Override
	public String alterar(Chale chale) {
		String sql = "UPDATE CHALE SET localizacao = ?, capacidade = ?, valorAltaEstacao = ?, valorBaixaEstacao = ? WHERE codChale = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, chale.getLocalizacao());
			ps.setInt(2, chale.getCapacidade());
			ps.setDouble(3, chale.getValorAltaEstacao());
			ps.setDouble(4, chale.getValorBaixaEstacao());
			ps.setInt(5, chale.getCodChale());
			int rowsAffected = ps.executeUpdate();
			if (rowsAffected > 0) {
				return "Chalé atualizado com sucesso!";
			} else {
				return "Erro ao atualizar chalé!";
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return "Erro ao atualizar chalé: " + e.getMessage();
		}
	}
	@Override
	public String excluir(Chale chale) {
		String sql = "DELETE FROM CHALE WHERE codChale = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, chale.getCodChale());
			ps.executeUpdate();
			return "Chalé excluído com sucesso!";
		} catch (SQLException e) {
			e.printStackTrace();
			return "Erro ao excluir chalé: " + e.getMessage();
		}
	}
	@Override
	public List<Chale> listarTodos() {
		List<Chale> chales = new ArrayList<>();
		String sql = "SELECT * FROM CHALE";
		try (PreparedStatement ps = connection.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Chale chale = new Chale();
				chale.setCodChale(rs.getInt("codChale"));
				chale.setLocalizacao(rs.getString("localizacao"));
				chale.setCapacidade(rs.getInt("capacidade"));
				chale.setValorAltaEstacao(rs.getDouble("valorAltaEstacao"));
				chale.setValorBaixaEstacao(rs.getDouble("valorBaixaEstacao"));
				chales.add(chale);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return chales;
	}
	@Override
	public Chale pesquisarPorId(int id) {
		Chale chale = null;
		String sql = "SELECT * FROM CHALE WHERE codChale = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					chale = new Chale();
					chale.setCodChale(rs.getInt("codChale"));
					chale.setLocalizacao(rs.getString("localizacao"));
					chale.setCapacidade(rs.getInt("capacidade"));
					chale.setValorAltaEstacao(rs.getDouble("valorAltaEstacao"));
					chale.setValorBaixaEstacao(rs.getDouble("valorBaixaEstacao"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return chale;
	}
	@Override
	public double valorFinal(double valorBaixaEstacao, double valorAltaEstacao, int qtdPessoas) {
	    if (valorBaixaEstacao <= 0 || valorAltaEstacao <= 0) {
	        return 100 * qtdPessoas;
	    }
	    return Math.max(valorBaixaEstacao, valorAltaEstacao) * qtdPessoas;
	}
}

package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Item;
import com.pc2.hotel.persistence.ItemDAO;

public class ItemDAOImpl implements ItemDAO {
    private Connection connection;
    public ItemDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(Item item) {
        String sql = "INSERT INTO ITEM (nomeItem, descricaoItem) VALUES (?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, item.getNomeItem());
            ps.setString(2, item.getDescricaoItem());
            ps.executeUpdate();
            return "Item inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir item: " + e.getMessage();
        }
    }
    @Override
    public String alterar(Item item) {
        String sql = "UPDATE ITEM SET descricaoItem = ? WHERE nomeItem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, item.getDescricaoItem());
            ps.setString(2, item.getNomeItem());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "Item atualizado com sucesso!";
            } else {
                return "Erro ao atualizar item!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar item: " + e.getMessage();
        }
    }
    @Override
    public String excluir(Item item) {
        String sql = "DELETE FROM ITEM WHERE nomeItem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, item.getNomeItem());
            ps.executeUpdate();
            return "Item excluído com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir item: " + e.getMessage();
        }
    }
    @Override
    public List<Item> listarTodos() {
        List<Item> items = new ArrayList<>();
        String sql = "SELECT * FROM ITEM";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Item item = new Item();
                item.setNomeItem(rs.getString("nomeItem"));
                item.setDescricaoItem(rs.getString("descricaoItem"));
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
    @Override
    public Item pesquisarPorId(String nomeItem) {
        Item item = null;
        String sql = "SELECT * FROM ITEM WHERE nomeItem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, nomeItem);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    item = new Item();
                    item.setNomeItem(rs.getString("nomeItem"));
                    item.setDescricaoItem(rs.getString("descricaoItem"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return item;
    }

}

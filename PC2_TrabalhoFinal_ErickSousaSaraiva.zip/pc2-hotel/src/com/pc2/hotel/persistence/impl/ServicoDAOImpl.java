package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Servico;
import com.pc2.hotel.persistence.ServicoDAO;

public class ServicoDAOImpl implements ServicoDAO {
    private Connection connection;
    public ServicoDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(Servico servico) {
        String sql = "INSERT INTO SERVICO (nomeServico, valorServico) VALUES (?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, servico.getNomeServico());
            ps.setDouble(2, servico.getValorServico());
            ps.executeUpdate();
            return "Serviço inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir serviço: " + e.getMessage();
        }
    }
    @Override
    public String alterar(Servico servico) {
        String sql = "UPDATE SERVICO SET nomeServico = ?, valorServico = ? WHERE codServico = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, servico.getNomeServico());
            ps.setDouble(2, servico.getValorServico());
            ps.setInt(3, servico.getCodServico());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "Serviço atualizado com sucesso!";
            } else {
                return "Erro ao atualizar serviço!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar serviço: " + e.getMessage();
        }
    }
    @Override
    public String excluir(Servico servico) {
        String sql = "DELETE FROM SERVICO WHERE codServico = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, servico.getCodServico());
            ps.executeUpdate();
            return "Serviço excluído com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir serviço: " + e.getMessage();
        }
    }
    @Override
    public List<Servico> listarTodos() {
        List<Servico> servicos = new ArrayList<>();
        String sql = "SELECT * FROM SERVICO";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Servico servico = new Servico();
                servico.setCodServico(rs.getInt("codServico"));
                servico.setNomeServico(rs.getString("nomeServico"));
                servico.setValorServico(rs.getDouble("valorServico"));
                servicos.add(servico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return servicos;
    }
    @Override
    public Servico pesquisarPorId(int id) {
        Servico servico = null;
        String sql = "SELECT * FROM SERVICO WHERE codServico = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    servico = new Servico();
                    servico.setCodServico(rs.getInt("codServico"));
                    servico.setNomeServico(rs.getString("nomeServico"));
                    servico.setValorServico(rs.getDouble("valorServico"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return servico;
    }
}

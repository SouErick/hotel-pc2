package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.ChaleItem;
import com.pc2.hotel.persistence.ChaleItemDAO;

public class ChaleItemDAOImpl implements ChaleItemDAO {
    private Connection connection;
    public ChaleItemDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(ChaleItem chaleItem) {
        String sql = "INSERT INTO CHALE_ITEM (codChale, nomeItem) VALUES (?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, chaleItem.getCodChale());
            ps.setString(2, chaleItem.getNomeItem());
            ps.executeUpdate();
            return "ChaleItem inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir ChaleItem: " + e.getMessage();
        }
    }
    @Override
    public String alterar(ChaleItem chaleItem) {
        String sql = "UPDATE CHALE_ITEM SET nomeItem = ? WHERE codChale = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, chaleItem.getNomeItem());
            ps.setInt(2, chaleItem.getCodChale());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "ChaleItem alterado com sucesso!";
            } else {
                return "ChaleItem não encontrado!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao alterar ChaleItem: " + e.getMessage();
        }
    }
    @Override
    public String excluir(ChaleItem chaleItem) {
        String sql = "DELETE FROM CHALE_ITEM WHERE codChale = ? AND nomeItem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, chaleItem.getCodChale());
            ps.setString(2, chaleItem.getNomeItem());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "ChaleItem excluído com sucesso!";
            } else {
                return "ChaleItem não encontrado!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir ChaleItem: " + e.getMessage();
        }
    }
    @Override
    public List<ChaleItem> listarTodos() {
        List<ChaleItem> chaleItems = new ArrayList<>();
        String sql = "SELECT * FROM CHALE_ITEM";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ChaleItem chaleItem = new ChaleItem();
                chaleItem.setCodChale(rs.getInt("codChale"));
                chaleItem.setNomeItem(rs.getString("nomeItem"));
                chaleItems.add(chaleItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return chaleItems;
    }
    @Override
    public ChaleItem pesquisarPorId(int codChale, String nomeItem) {
        ChaleItem chaleItem = null;
        String sql = "SELECT * FROM CHALE_ITEM WHERE codChale = ? AND nomeItem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, codChale);
            ps.setString(2, nomeItem);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    chaleItem = new ChaleItem();
                    chaleItem.setCodChale(rs.getInt("codChale"));
                    chaleItem.setNomeItem(rs.getString("nomeItem"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return chaleItem;
    }
}

package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.HospedagemServico;
import com.pc2.hotel.persistence.HospedagemServicoDAO;

public class HospedagemServicoDAOImpl implements HospedagemServicoDAO {
    private Connection connection;
    public HospedagemServicoDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(HospedagemServico hospedagemServico) {
        String sql = "INSERT INTO HOSPEDAGEM_SERVICO (codHospedagem, dataServico, codServico, valorServico) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, hospedagemServico.getCodHospedagem());
            ps.setString(2, hospedagemServico.getDataServico());
            ps.setInt(3, hospedagemServico.getCodServico());
            ps.setDouble(4, hospedagemServico.getValorServico());
            ps.executeUpdate();
            return "Serviço inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir serviço: " + e.getMessage();
        }
    }

    @Override
    public String alterar(HospedagemServico hospedagemServico) {
        String sql = "UPDATE HOSPEDAGEM_SERVICO SET dataServico = ?, codServico = ?, valorServico = ? WHERE codHospedagem = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, hospedagemServico.getDataServico());
            ps.setInt(2, hospedagemServico.getCodServico());
            ps.setDouble(3, hospedagemServico.getValorServico());
            ps.setInt(4, hospedagemServico.getCodHospedagem());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return "Serviço atualizado com sucesso!";
            } else {
                return "Erro ao atualizar serviço!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar serviço: " + e.getMessage();
        }
    }

    @Override
    public String excluir(HospedagemServico hospedagemServico) {
        String sql = "DELETE FROM HOSPEDAGEM_SERVICO WHERE codHospedagem = ? AND codServico = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, hospedagemServico.getCodHospedagem());
            ps.setInt(2, hospedagemServico.getCodServico());
            ps.executeUpdate();
            return "Serviço excluído com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir serviço: " + e.getMessage();
        }
    }

    @Override
    public List<HospedagemServico> listarTodos() {
        List<HospedagemServico> hospedagemServicos = new ArrayList<>();
        String sql = "SELECT * FROM HOSPEDAGEM_SERVICO";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                HospedagemServico hospedagemServico = new HospedagemServico();
                hospedagemServico.setCodHospedagem(rs.getInt("codHospedagem"));
                hospedagemServico.setDataServico(rs.getString("dataServico"));
                hospedagemServico.setCodServico(rs.getInt("codServico"));
                hospedagemServico.setValorServico(rs.getDouble("valorServico"));
                hospedagemServicos.add(hospedagemServico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hospedagemServicos;
    }
    @Override
    public HospedagemServico pesquisarPorId(int codHospedagem, int codServico) {
        HospedagemServico hospedagemServico = null;
        String sql = "SELECT * FROM HOSPEDAGEM_SERVICO WHERE codHospedagem = ? AND codServico = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, codHospedagem);
            ps.setInt(2, codServico);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    hospedagemServico = new HospedagemServico();
                    hospedagemServico.setCodHospedagem(rs.getInt("codHospedagem"));
                    hospedagemServico.setDataServico(rs.getString("dataServico"));
                    hospedagemServico.setCodServico(rs.getInt("codServico"));
                    hospedagemServico.setValorServico(rs.getDouble("valorServico"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return hospedagemServico;
    }
}

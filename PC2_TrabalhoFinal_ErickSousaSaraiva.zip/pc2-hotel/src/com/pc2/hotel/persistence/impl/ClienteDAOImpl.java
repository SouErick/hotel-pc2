package com.pc2.hotel.persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc2.hotel.model.Cliente;
import com.pc2.hotel.persistence.ClienteDAO;

public class ClienteDAOImpl implements ClienteDAO {
    private Connection connection;
    public ClienteDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public String inserir(Cliente cliente) {
        String sql = "INSERT INTO CLIENTE (nomeCliente, rgCliente, nascimentoCliente) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, cliente.getNomeCliente());
            ps.setString(2, cliente.getRgCliente());
            ps.setString(3, cliente.getNascimentoCliente());
            ps.executeUpdate();
            return "Cliente inserido com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao inserir cliente: " + e.getMessage();
        }
    }
    @Override
    public String alterar(Cliente cliente) {
        String sql = "UPDATE CLIENTE SET nomeCliente = ?, rgCliente = ?, nascimentoCliente = ? WHERE codCliente = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setString(2, cliente.getRgCliente());
            stmt.setString(3, cliente.getNascimentoCliente());
            stmt.setInt(4, cliente.getCodCliente());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                return "Cliente atualizado com sucesso!";
            } else {
                return "Erro ao atualizar cliente!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar cliente: " + e.getMessage();
        }
    }
    @Override
    public String excluir(Cliente cliente) {
        String sql = "DELETE FROM CLIENTE WHERE codCliente = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, cliente.getCodCliente());
            stmt.executeUpdate();
            return "Cliente excluído com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao excluir cliente: " + e.getMessage();
        }
    }
    @Override
    public List<Cliente> listarTodos() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM CLIENTE";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setCodCliente(rs.getInt("codCliente"));
                cliente.setNomeCliente(rs.getString("nomeCliente"));
                cliente.setRgCliente(rs.getString("rgCliente"));
                cliente.setNascimentoCliente(rs.getString("nascimentoCliente"));
                clientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }
    @Override
    public Cliente pesquisarPorId(int id) {
        Cliente cliente = null;
        String sql = "SELECT * FROM CLIENTE WHERE codCliente = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setCodCliente(rs.getInt("codCliente"));
                    cliente.setNomeCliente(rs.getString("nomeCliente"));
                    cliente.setRgCliente(rs.getString("rgCliente"));
                    cliente.setNascimentoCliente(rs.getString("nascimentoCliente"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cliente;
    }
}

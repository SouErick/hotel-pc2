package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.Telefone;

public interface TelefoneDAO {
    public String inserir(Telefone telefone);
    public String alterar(Telefone telefone);
    public String excluir(Telefone telefone);
    public List<Telefone> listarTodos();
    public Telefone pesquisarPorId(int id);
}

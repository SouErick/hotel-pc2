package com.pc2.hotel.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectorDB {

    public static Connection connect() {
        Connection connection = null;
        String driver = "org.postgresql.Driver";
        String url = "jdbc:postgresql://localhost:5432/pc2_hotel";
        String user = "postgres";
        String senha = "123";
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, user, senha);
            System.out.println("Conexão estabelecida com sucesso!");
        } catch (ClassNotFoundException ex) {
            System.err.println("Driver não encontrado: " + ex.getMessage());
        } catch (SQLException e) {
            System.err.println("Erro ao conectar: " + e.getMessage());
        }

        return connection;
    }
    public static void close(Connection con) {
        if (con != null) {
            try {
                con.close();
                System.out.println("Conexão fechada com sucesso.");
            } catch (SQLException e) {
                System.err.println("Erro ao fechar a conexão: " + e.getMessage());
            }
        }
    }
    public static void main(String[] args) {
        Connection connection = connect();
        close(connection);
    }
}

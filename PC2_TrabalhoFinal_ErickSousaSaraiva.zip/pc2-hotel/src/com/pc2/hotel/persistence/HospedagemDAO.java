package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.Hospedagem;

public interface HospedagemDAO {
    public String inserir(Hospedagem hospedagem);
    public String alterar(Hospedagem hospedagem);
    public String excluir(Hospedagem hospedagem);
    public List<Hospedagem> listarTodos();
    public Hospedagem pesquisarPorId(int id);
}

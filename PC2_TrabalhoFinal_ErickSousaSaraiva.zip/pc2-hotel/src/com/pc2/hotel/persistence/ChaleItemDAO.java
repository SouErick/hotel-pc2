package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.ChaleItem;

public interface ChaleItemDAO {
    public String inserir(ChaleItem chaleItem);
    public String alterar(ChaleItem chaleItem);
    public String excluir(ChaleItem chaleItem);
    public List<ChaleItem> listarTodos();
    public ChaleItem pesquisarPorId(int codChale, String nomeItem);
}

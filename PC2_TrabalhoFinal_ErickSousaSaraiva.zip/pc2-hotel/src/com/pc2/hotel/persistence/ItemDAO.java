package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.Item;

public interface ItemDAO {
    public String inserir(Item item);
    public String alterar(Item item);
    public String excluir(Item item);
    public List<Item> listarTodos();
    public Item pesquisarPorId(String nomeItem);
}

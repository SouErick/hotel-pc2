package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.Servico;

public interface ServicoDAO {
    public String inserir(Servico servico);
    public String alterar(Servico servico);
    public String excluir(Servico servico);
    public List<Servico> listarTodos();
    public Servico pesquisarPorId(int id);
}

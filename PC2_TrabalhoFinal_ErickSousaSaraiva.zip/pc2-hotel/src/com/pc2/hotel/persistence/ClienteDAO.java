package com.pc2.hotel.persistence;

import java.util.List;

import com.pc2.hotel.model.Cliente;

public interface ClienteDAO {
	public String inserir(Cliente cliente);
	public String alterar(Cliente cliente);
	public String excluir(Cliente cliente);
	public List<Cliente> listarTodos();
	public Cliente pesquisarPorId(int id);
}

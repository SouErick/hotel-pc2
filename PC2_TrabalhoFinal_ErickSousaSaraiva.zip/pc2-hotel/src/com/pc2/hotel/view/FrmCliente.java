package com.pc2.hotel.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.pc2.hotel.controller.ClienteController;
import com.pc2.hotel.model.Cliente;
import com.pc2.hotel.persistence.ClienteDAO;
import com.pc2.hotel.persistence.ConnectorDB;
import com.pc2.hotel.persistence.impl.ClienteDAOImpl;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class FrmCliente extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblConsulta;
	private JTextField txtCod;
	private JTextField txtNome;
	private JTextField txtRG;
	private JTextField txtData;
	private JLabel lblMensagem;
	private Connection connection = ConnectorDB.connect();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmCliente frame = new FrmCliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmCliente() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 830, 560);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		JPanel panel = new JPanel();

		JPanel panel_1 = new JPanel();

		JPanel panel_2 = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
				.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
				.addComponent(panel, GroupLayout.PREFERRED_SIZE, 452, Short.MAX_VALUE));
		gl_contentPane
				.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(Alignment.TRAILING,
						gl_contentPane.createSequentialGroup()
								.addComponent(panel, GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 236, GroupLayout.PREFERRED_SIZE)));

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE).addContainerGap()));
		gl_panel_2.setVerticalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE).addContainerGap()));

		tblConsulta = new JTable();
		tblConsulta.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "codCliente", "nomeCliente", "rgCliente", "nascimentoCliente" }) {
			Class[] columnTypes = new Class[] { Integer.class, String.class, String.class, String.class };

			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tblConsulta.getColumnModel().getColumn(0).setResizable(false);
		tblConsulta.getColumnModel().getColumn(1).setResizable(false);
		tblConsulta.getColumnModel().getColumn(2).setResizable(false);
		tblConsulta.getColumnModel().getColumn(3).setResizable(false);
		tblConsulta.getColumnModel().getColumn(3).setPreferredWidth(95);
		scrollPane.setViewportView(tblConsulta);
		panel_2.setLayout(gl_panel_2);

		JButton btnNewButton = new JButton("INSERIR");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ClienteDAO cd = new ClienteDAOImpl(connection);
				ClienteController cc = new ClienteController(cd);
				int codCliente = Integer.parseInt(txtCod.getText());
				Cliente clExistente = cc.pesquisarClientePorId(codCliente);
				if (clExistente != null) {
					txtNome.setText(clExistente.getNomeCliente());
					txtRG.setText(clExistente.getRgCliente());
					txtData.setText(clExistente.getNascimentoCliente());
					JOptionPane.showMessageDialog(null, "Cliente com código " + codCliente + " já existe!");
				} else {
					Cliente clNovo = new Cliente();
					clNovo.setCodCliente(codCliente);
					clNovo.setNomeCliente(txtNome.getText());
					clNovo.setRgCliente(txtRG.getText());
					clNovo.setNascimentoCliente(txtData.getText());
					lblMensagem.setText(cc.inserirCliente(clNovo));
					JOptionPane.showMessageDialog(null, "Cliente inserido com sucesso!");
				}
			}
		});

		JButton btnAlterar = new JButton("ALTERAR");
		btnAlterar.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				ClienteDAO cd = new ClienteDAOImpl(connection);
				Cliente cl = new Cliente();
				ClienteController cc = new ClienteController(cd);
				cl.setCodCliente(Integer.parseInt(txtCod.getText()));
				cl.setNomeCliente(txtNome.getText());
				cl.setRgCliente(txtRG.getText());
				cl.setNascimentoCliente(txtData.getText());
				lblMensagem.setText(cc.alterarCliente(cl));
			}
		});
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});

		JButton btnExcluir = new JButton("EXCLUIR");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClienteDAO cd = new ClienteDAOImpl(connection);
				Cliente cl = new Cliente();
				ClienteController cc = new ClienteController(cd);
				cl.setCodCliente(Integer.parseInt(txtCod.getText()));
				Object[] opcoes = { "Sim", "Não" };
				int i = JOptionPane.showOptionDialog(null, "Deseja excluir esse Cliente: " + txtNome.getText() + "?",
						"Exclusão", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);
				if (JOptionPane.YES_OPTION == i) {
					lblMensagem.setText(cc.excluirCliente(cl));
				}
			}
		});

		JButton btnPesquisar = new JButton("PESQUISAR POR COD");
		btnPesquisar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ClienteDAO cd = new ClienteDAOImpl(connection);
				ClienteController cc = new ClienteController(cd);
				int codCliente = Integer.parseInt(txtCod.getText());
				Cliente cl = cc.pesquisarClientePorId(codCliente);
				if (cl != null) {
					txtNome.setText(cl.getNomeCliente());
					txtRG.setText(cl.getRgCliente());
					txtData.setText(cl.getNascimentoCliente());
					lblMensagem.setText("Cliente encontrado.");
				} else {
					lblMensagem.setText("Cliente não encontrado.");
				}
			}
		});

		JButton btnLimpar = new JButton("LIMPAR");
		btnLimpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtCod.setText("");
				txtNome.setText("");
				txtRG.setText("");
				txtData.setText("");
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}

			}
		});

		JButton btnSair = new JButton("SAIR");
		btnSair.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmCliente.this.dispose();
			}
		});
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});

		JButton btnPesquisar_2 = new JButton("PESQUISAR");
		btnPesquisar_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Cliente> listaCliente = new ArrayList();
				ClienteDAO cd = new ClienteDAOImpl(connection);
				Cliente cl = new Cliente();
				ClienteController cc = new ClienteController(cd);
				listaCliente = cc.listarTodosClientes();
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
				int i = 0;
				for (Cliente obj : listaCliente) {
					tbm.addRow(new String[1]);
					tblConsulta.setValueAt(obj.getCodCliente(), i, 0);
					tblConsulta.setValueAt(obj.getNomeCliente(), i, 1);
					tblConsulta.setValueAt(obj.getRgCliente(), i, 2);
					tblConsulta.setValueAt(obj.getNascimentoCliente(), i, 3);
					i++;
				}
			}
		});
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addContainerGap().addComponent(btnNewButton)
						.addPreferredGap(ComponentPlacement.RELATED).addComponent(btnAlterar)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnExcluir, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED).addComponent(btnPesquisar)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnPesquisar_2, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED, 161, Short.MAX_VALUE).addComponent(btnLimpar)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnSair, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
						.addContainerGap()));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup().addContainerGap(17, Short.MAX_VALUE)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE).addComponent(btnNewButton)
								.addComponent(btnAlterar).addComponent(btnExcluir).addComponent(btnLimpar)
								.addComponent(btnSair).addComponent(btnPesquisar).addComponent(btnPesquisar_2))
						.addContainerGap()));
		panel_1.setLayout(gl_panel_1);

		JLabel lblNewLabel = new JLabel("Código: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));

		JLabel lblNewLabel_1 = new JLabel("Nome: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));

		JLabel lblNewLabel_2 = new JLabel("RG: ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));

		JLabel lblNewLabel_3 = new JLabel("Data de Nascimento:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 10));

		txtCod = new JTextField();
		txtCod.setColumns(10);

		txtNome = new JTextField();
		txtNome.setColumns(10);

		txtRG = new JTextField();
		txtRG.setColumns(10);

		txtData = new JTextField();
		txtData.setColumns(10);

		lblMensagem = new JLabel("Mensagem");
		lblMensagem.setForeground(new Color(0, 128, 255));
		lblMensagem.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtData, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(lblNewLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(txtRG)
								.addComponent(txtNome)
								.addComponent(txtCod, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)))
						.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 773, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(240, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(txtCod, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(txtNome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(txtRG, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(txtData, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
					.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
	}
}

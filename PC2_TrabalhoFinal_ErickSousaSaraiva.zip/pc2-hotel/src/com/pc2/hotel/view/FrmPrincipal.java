package com.pc2.hotel.view;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class FrmPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel statusBar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPrincipal frame = new FrmPrincipal();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmPrincipal() {
		setTitle("Sistema de Gerenciamento de Hotel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnCadastro = new JMenu("Cadastro");
		menuBar.add(mnCadastro);
		
		JMenuItem mntmCliente = new JMenuItem("Cliente");
		mntmCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmCliente fc = new FrmCliente();
				fc.setTitle("Cadastro de Cliente");
				fc.setLocationRelativeTo(null);
				fc.setVisible(true);
				statusBar.setText("Tela de cadastro de cliente aberta.");
			}
		});
		mnCadastro.add(mntmCliente);
		
		JMenuItem mntmEndereco = new JMenuItem("Endereço");
		mntmEndereco.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmEndereco fe = new FrmEndereco();
				fe.setTitle("Cadastro de Endereços");
				fe.setLocationRelativeTo(null);
				fe.setVisible(true);
				statusBar.setText("Tela de cadastro de endereço aberta.");
			}
		});
		mnCadastro.add(mntmEndereco);
		
		JMenuItem mntmChale = new JMenuItem("Chale");
		mntmChale.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmChale fc = new FrmChale();
				fc.setTitle("Cadastro de Chalé");
				fc.setLocationRelativeTo(null);
				fc.setVisible(true);
				statusBar.setText("Tela de cadastro de chalé aberta.");
			}
		});
		mnCadastro.add(mntmChale);
		
		JMenuItem mntmHospedagem = new JMenuItem("Hospedagem");
		mntmHospedagem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmHospedagem fh = new FrmHospedagem();
				fh.setTitle("Cadastro de Hospedagem");
				fh.setLocationRelativeTo(null);
				fh.setVisible(true);
				statusBar.setText("Tela de cadastro de hospedagem aberta.");
			}
		});
		mnCadastro.add(mntmHospedagem);
		
		JMenuItem mntmSair = new JMenuItem("Sair");
		mntmSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnCadastro.add(mntmSair);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		statusBar = new JLabel("Bem-vindo ao sistema de hotel.");
		statusBar.setHorizontalAlignment(SwingConstants.LEFT);
		
		JLabel lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/hotel.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
		    gl_contentPane.createParallelGroup(Alignment.LEADING)
		        .addComponent(statusBar, GroupLayout.PREFERRED_SIZE, 576, GroupLayout.PREFERRED_SIZE)
		        .addGroup(gl_contentPane.createSequentialGroup()
		            .addGap(100)  
		            .addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)  // Tamanho ajustável para centralizar
		            .addGap(100))  
		);
		gl_contentPane.setVerticalGroup(
		    gl_contentPane.createParallelGroup(Alignment.LEADING)
		        .addGroup(gl_contentPane.createSequentialGroup()
		            .addGap(21)
		            .addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 233, GroupLayout.PREFERRED_SIZE)
		            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
		            .addComponent(statusBar))
		);
		contentPane.setLayout(gl_contentPane);
	}
}

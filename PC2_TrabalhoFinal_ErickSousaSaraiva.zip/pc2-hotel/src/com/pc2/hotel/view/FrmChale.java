package com.pc2.hotel.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.pc2.hotel.controller.ChaleController;
import com.pc2.hotel.model.Chale;
import com.pc2.hotel.persistence.ChaleDAO;
import com.pc2.hotel.persistence.ConnectorDB;
import com.pc2.hotel.persistence.impl.ChaleDAOImpl;

public class FrmChale extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblConsulta;
	private JTextField txtCod;
	private JTextField txtLoc;
	private JTextField txtCapacidade;
	private JTextField txtValorAlto;
	private JTextField txtValorBaixo;
	private JLabel lblMensagem;
	private Connection connection = ConnectorDB.connect();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmChale frame = new FrmChale();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmChale() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 926, 494);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		lblMensagem = new JLabel("Mensagem");
		JPanel panel = new JPanel();

		JPanel panel_1 = new JPanel();

		JPanel panel_2 = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 840, Short.MAX_VALUE)
								.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 840, Short.MAX_VALUE)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 817, GroupLayout.PREFERRED_SIZE))
						.addContainerGap()));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 820, Short.MAX_VALUE).addContainerGap()));
		gl_panel_2.setVerticalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		tblConsulta = new JTable();
		tblConsulta.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "codChale", "localizacao", "capacidade", "valorAltaEstacao", "valorBaixaEstacao" }) {
			Class[] columnTypes = new Class[] { Integer.class, String.class, Integer.class, Double.class,
					Double.class };

			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false, false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tblConsulta.getColumnModel().getColumn(0).setResizable(false);
		tblConsulta.getColumnModel().getColumn(1).setResizable(false);
		tblConsulta.getColumnModel().getColumn(2).setResizable(false);
		tblConsulta.getColumnModel().getColumn(3).setResizable(false);
		tblConsulta.getColumnModel().getColumn(3).setPreferredWidth(88);
		tblConsulta.getColumnModel().getColumn(4).setResizable(false);
		tblConsulta.getColumnModel().getColumn(4).setPreferredWidth(95);
		scrollPane.setViewportView(tblConsulta);
		panel_2.setLayout(gl_panel_2);

		JButton btnNewButton = new JButton("INSERIR");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ChaleDAO cd = new ChaleDAOImpl(connection);
				ChaleController cc = new ChaleController(cd);
				int codChale = Integer.parseInt(txtCod.getText());
				Chale clExistente = cc.pesquisarPorId(codChale);
				if (clExistente != null) {
					txtCapacidade.setText(String.valueOf(clExistente.getCapacidade()));
					txtLoc.setText(clExistente.getLocalizacao());
					txtValorAlto.setText(String.valueOf(clExistente.getValorAltaEstacao()));
					txtValorBaixo.setText(String.valueOf(clExistente.getValorBaixaEstacao()));
					JOptionPane.showMessageDialog(null, "Chale com código " + codChale + " já existe!");
				} else {
					Chale clNovo = new Chale();
					clNovo.setCapacidade(Integer.parseInt(txtCapacidade.getText())); // Capacidade como Integer
					clNovo.setLocalizacao(txtLoc.getText());
					clNovo.setValorAltaEstacao(Double.parseDouble(txtValorAlto.getText())); // Valor Alto como Double
					clNovo.setValorBaixaEstacao(Double.parseDouble(txtValorBaixo.getText())); // Valor Baixo como Double
					lblMensagem.setText(cc.inserir(clNovo));
					JOptionPane.showMessageDialog(null, "Chale inserido com sucesso!");
				}
			}
		});

		JButton btnAlterar = new JButton("ALTERAR");
		btnAlterar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ChaleDAO cd = new ChaleDAOImpl(connection);
				Chale cl = new Chale();
				ChaleController cc = new ChaleController(cd);
				cl.setCodChale(Integer.parseInt(txtCod.getText())); 
				cl.setCapacidade(Integer.parseInt(txtCapacidade.getText())); 
				cl.setLocalizacao(txtLoc.getText());
				cl.setValorAltaEstacao(Double.parseDouble(txtValorAlto.getText())); 
				cl.setValorBaixaEstacao(Double.parseDouble(txtValorBaixo.getText())); 
				lblMensagem.setText(cc.alterar(cl)); 
			}
		});

		JButton btnExcluir = new JButton("EXCLUIR");
		btnExcluir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ChaleDAO cd = new ChaleDAOImpl(connection);
				Chale cl = new Chale();
				ChaleController cc = new ChaleController(cd);
				cl.setCodChale(Integer.parseInt(txtCod.getText())); 
				Object[] opcoes = { "Sim", "Não" };
				int i = JOptionPane.showOptionDialog(null, "Deseja excluir esse Chalé com código: " + txtCod.getText() + "?",
				        "Exclusão", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);
				if (JOptionPane.YES_OPTION == i) {
				    lblMensagem.setText(cc.excluir(cl)); 
				}
			}
		});

		JButton btnPesquisar = new JButton("PESQUISAR POR COD");
		btnPesquisar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ChaleDAO cd = new ChaleDAOImpl(connection);
				ChaleController cc = new ChaleController(cd);
				int codChale = Integer.parseInt(txtCod.getText()); 
				Chale cl = cc.pesquisarPorId(codChale); 
				if (cl != null) {
					txtCapacidade.setText(String.valueOf(cl.getCapacidade())); 
					txtLoc.setText(cl.getLocalizacao());
					txtValorAlto.setText(String.valueOf(cl.getValorAltaEstacao())); 
					txtValorBaixo.setText(String.valueOf(cl.getValorBaixaEstacao())); 
					lblMensagem.setText("Chalé encontrado.");
				} else {
					lblMensagem.setText("Chalé não encontrado.");
				}
			}
		});

		JButton btnPesquisar_2 = new JButton("PESQUISAR");
		btnPesquisar_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Chale> listaChale = new ArrayList<>();
				ChaleDAO cd = new ChaleDAOImpl(connection);
				ChaleController cc = new ChaleController(cd);
				listaChale = cc.listarTodos();
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
				int i = 0;
				for (Chale obj : listaChale) {
					tbm.addRow(new Object[4]);
					tblConsulta.setValueAt(obj.getCodChale(), i, 0);
					tblConsulta.setValueAt(obj.getLocalizacao(), i, 1);
					tblConsulta.setValueAt(obj.getCapacidade(), i, 2);
					tblConsulta.setValueAt(obj.getValorAltaEstacao(), i, 3);
					tblConsulta.setValueAt(obj.getValorBaixaEstacao(), i, 4);
					i++;
				}
			}
		});

		JButton btnLimpar = new JButton("LIMPAR");
		btnLimpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtCod.setText("");
				txtLoc.setText("");
				txtCapacidade.setText("");
				txtValorAlto.setText("");
				txtValorBaixo.setText("");
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
			}
		});

		JButton btnSair = new JButton("SAIR");
		btnSair.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmChale.this.dispose();
			}
		});
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addContainerGap()
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnExcluir, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnPesquisar, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnPesquisar_2, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
						.addGap(46).addComponent(btnLimpar, GroupLayout.PREFERRED_SIZE, 96, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnSair, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(39, Short.MAX_VALUE)));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup().addGap(38)
								.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE).addComponent(btnPesquisar)
										.addComponent(btnPesquisar_2).addComponent(btnLimpar).addComponent(btnSair)))
						.addGroup(gl_panel_1.createSequentialGroup().addGap(38).addComponent(btnNewButton))
						.addGroup(gl_panel_1.createSequentialGroup().addGap(38).addComponent(btnExcluir))
						.addGroup(gl_panel_1.createSequentialGroup().addGap(38).addComponent(btnAlterar)))
						.addContainerGap(24, Short.MAX_VALUE)));
		panel_1.setLayout(gl_panel_1);

		JLabel lblNewLabel = new JLabel("Código: ");

		JLabel lblNewLabel_1 = new JLabel("Localização");

		JLabel lblNewLabel_2 = new JLabel("Capacidade");

		JLabel lblNewLabel_3 = new JLabel("Valor Alto: ");

		JLabel lblNewLabel_4 = new JLabel("Valor Baixo: ");

		lblMensagem.setForeground(new Color(0, 128, 255));
		lblMensagem.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 10));

		txtCod = new JTextField();
		txtCod.setColumns(10);

		txtLoc = new JTextField();
		txtLoc.setColumns(10);

		txtCapacidade = new JTextField();
		txtCapacidade.setColumns(10);

		txtValorAlto = new JTextField();
		txtValorAlto.setColumns(10);

		txtValorBaixo = new JTextField();
		txtValorBaixo.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
						.createSequentialGroup()
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lblNewLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 64,
												Short.MAX_VALUE)
										.addComponent(lblNewLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addComponent(lblNewLabel_4))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addComponent(txtCod, GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE)
								.addComponent(txtValorBaixo, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 596,
										Short.MAX_VALUE)
								.addComponent(txtCapacidade, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 596,
										Short.MAX_VALUE)
								.addComponent(txtValorAlto, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 596,
										Short.MAX_VALUE)
								.addComponent(txtLoc, GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE)))
						.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 662, GroupLayout.PREFERRED_SIZE))
				.addContainerGap()));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel)
						.addComponent(txtCod, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.UNRELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_1).addComponent(
						txtLoc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.UNRELATED)
				.addGroup(gl_panel
						.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_2).addComponent(txtCapacidade,
								GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.LEADING).addComponent(lblNewLabel_3).addGroup(gl_panel
						.createSequentialGroup()
						.addComponent(txtValorAlto, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addGap(5)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(txtValorBaixo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_4))))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
				.addContainerGap(12, Short.MAX_VALUE)));
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
	}
}

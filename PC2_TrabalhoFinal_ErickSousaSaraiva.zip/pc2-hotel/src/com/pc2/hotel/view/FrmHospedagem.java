package com.pc2.hotel.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.pc2.hotel.controller.ChaleController;
import com.pc2.hotel.controller.ClienteController;
import com.pc2.hotel.controller.EnderecoController;
import com.pc2.hotel.controller.HospedagemController;
import com.pc2.hotel.model.Chale;
import com.pc2.hotel.model.Cliente;
import com.pc2.hotel.model.Endereco;
import com.pc2.hotel.model.Hospedagem;
import com.pc2.hotel.persistence.ChaleDAO;
import com.pc2.hotel.persistence.ClienteDAO;
import com.pc2.hotel.persistence.ConnectorDB;
import com.pc2.hotel.persistence.EnderecoDAO;
import com.pc2.hotel.persistence.HospedagemDAO;
import com.pc2.hotel.persistence.impl.ChaleDAOImpl;
import com.pc2.hotel.persistence.impl.ClienteDAOImpl;
import com.pc2.hotel.persistence.impl.EnderecoDAOImpl;
import com.pc2.hotel.persistence.impl.HospedagemDAOImpl;

public class FrmHospedagem extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtDataInicio;
	private JTextField txtDataFim;
	private JTextField txtCod;
	private JTextField txtQuantidade;
	private JTable tblConsulta;
	private Connection connection = ConnectorDB.connect();
	private ClienteDAO cd = new ClienteDAOImpl(connection);
	private ClienteController cc = new ClienteController(cd);
	private ChaleDAO chd = new ChaleDAOImpl(connection);
	private ChaleController chc = new ChaleController(chd);
	private Hospedagem hosp = new Hospedagem();
	private HospedagemDAO hd = new HospedagemDAOImpl(connection);
	private HospedagemController hc = new HospedagemController(hd);
	private List<Hospedagem> listaHosp = hc.listarTodos();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmHospedagem frame = new FrmHospedagem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmHospedagem() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 930, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		JPanel panel = new JPanel();

		JPanel panel_1 = new JPanel();

		JPanel panel_2 = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(panel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(panel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE))
						.addContainerGap(19, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 258, GroupLayout.PREFERRED_SIZE)));

		JLabel lblNewLabel = new JLabel("Código Chale: ");

		JLabel lblNewLabel_1 = new JLabel("Código Cliente: ");

		JLabel lblNewLabel_2 = new JLabel("Código: ");

		JLabel lblNewLabel_3 = new JLabel("Estado:");

		JLabel lblNewLabel_4 = new JLabel("Data Inicio: ");

		JLabel lblNewLabel_5 = new JLabel("Data Fim:");

		JLabel lblNewLabel_6 = new JLabel("Quantidade");

		List<Chale> listaChale = chc.listarTodos();
		JComboBox<Integer> cbxChale = new JComboBox();
		for (Chale obj : listaChale) {
			cbxChale.addItem(obj.getCodChale());
		}
		List<Cliente> listaCliente = cc.listarTodosClientes();
		JComboBox<Integer> cbxCliente = new JComboBox<>();
		for (Cliente obj : listaCliente) {
			cbxCliente.addItem(obj.getCodCliente());
		}

		JComboBox cbxEstado = new JComboBox();
		cbxEstado.setModel(new DefaultComboBoxModel(
				new String[] { "", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
						"PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));

		txtDataInicio = new JTextField();
		txtDataInicio.setColumns(10);

		txtDataFim = new JTextField();
		txtDataFim.setColumns(10);

		txtCod = new JTextField();
		txtCod.setColumns(10);

		txtQuantidade = new JTextField();
		txtQuantidade.setColumns(10);

		JLabel lblMensagem = new JLabel("Mensagem");
		lblMensagem.setForeground(new Color(0, 128, 255));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
						.createSequentialGroup()
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lblNewLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(
												lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 85,
												Short.MAX_VALUE))
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lblNewLabel_6, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_5, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_4, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 76,
												Short.MAX_VALUE)))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(txtQuantidade, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(txtCod, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(txtDataFim, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
										.addComponent(cbxCliente, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(cbxChale, 0, 584, Short.MAX_VALUE)
										.addComponent(txtDataInicio, GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(cbxEstado, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
						.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 786, GroupLayout.PREFERRED_SIZE))
				.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel).addComponent(
						cbxChale, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_1).addComponent(
						cbxCliente, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_2).addComponent(
						txtCod, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_3).addComponent(
						cbxEstado, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel
						.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_4).addComponent(txtDataInicio,
								GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_5).addComponent(
						txtDataFim, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.LEADING).addComponent(lblNewLabel_6).addComponent(
						txtQuantidade, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
						GroupLayout.PREFERRED_SIZE))
				.addGap(18).addComponent(lblMensagem).addContainerGap(23, Short.MAX_VALUE)));
		panel.setLayout(gl_panel);

		JButton btnNewButton = new JButton("INSERIR");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					hosp.setCodChale((Integer) cbxChale.getSelectedItem());
					hosp.setCodCliente((Integer) cbxCliente.getSelectedItem());
					hosp.setDataInicio(txtDataInicio.getText());
					hosp.setDataFim(txtDataFim.getText());
					hosp.setEstado(cbxEstado.getSelectedItem().toString());
					hosp.setQtdPessoas(Integer.parseInt(txtQuantidade.getText()));
					hc.inserir(hosp); 
					lblMensagem.setForeground(Color.GREEN);
					lblMensagem.setText("Hospedagem inserida com sucesso!");
				} catch (Exception ex) {
					lblMensagem.setForeground(Color.RED);
					lblMensagem.setText("Erro ao inserir hospedagem: " + ex.getMessage());
				}
			}
		});

		JButton btnAlterar = new JButton("ALTERAR");
		btnAlterar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!txtCod.getText().isEmpty()) {
					try {
						int codHospedagem = Integer.parseInt(txtCod.getText());
						Hospedagem hospedagemExistente = listaHosp.stream()
								.filter(hosp -> hosp.getCodHospedagem() == codHospedagem).findFirst().orElse(null);
						if (hospedagemExistente != null) {
							hospedagemExistente.setCodChale((Integer) cbxChale.getSelectedItem());
							hospedagemExistente.setCodCliente((Integer) cbxCliente.getSelectedItem());
							hospedagemExistente.setDataInicio(txtDataInicio.getText());
							hospedagemExistente.setDataFim(txtDataFim.getText());
							hospedagemExistente.setEstado(cbxEstado.getSelectedItem().toString());
							hospedagemExistente.setQtdPessoas(Integer.parseInt(txtQuantidade.getText()));
							String mensagem = hc.alterar(hospedagemExistente);
							lblMensagem.setText(mensagem);
							listaHosp = hc.listarTodos();
						} else {
							lblMensagem.setText("Hospedagem não encontrada para alteração.");
						}
					} catch (NumberFormatException ex) {
						lblMensagem.setText("Código inválido para alteração.");
					}
				} else {
					lblMensagem.setText("Preencha o código da hospedagem para alterar.");
				}
			}
		});

		JButton btnExcluir = new JButton("EXCLUIR");
		btnExcluir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtCod.getText().isEmpty()) {
					lblMensagem.setText("Preencha o código da hospedagem.");
					return;
				}
				HospedagemDAO hd = new HospedagemDAOImpl(connection);
				HospedagemController hc = new HospedagemController(hd);
				try {
					Hospedagem hospedagem = new Hospedagem();
					hospedagem.setCodHospedagem(Integer.parseInt(txtCod.getText()));
					Object[] opcoes = { "Sim", "Não" };
					int i = JOptionPane.showOptionDialog(null,
							"Deseja excluir essa Hospedagem com o código: " + txtCod.getText() + "?", "Exclusão",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);

					if (JOptionPane.YES_OPTION == i) {
						String mensagem = hc.excluir(hospedagem);
						lblMensagem.setText(mensagem);
					}
				} catch (NumberFormatException ex) {
					lblMensagem.setText("Código inválido.");
				} catch (Exception ex) {
					lblMensagem.setText("Erro ao excluir hospedagem: " + ex.getMessage());
				}
			}
		});

		JButton btnPesquisar = new JButton("PESQUISAR POR COD");
		btnPesquisar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!txtCod.getText().isEmpty()) {
					try {
						int codHospedagem = Integer.parseInt(txtCod.getText());
						HospedagemDAO hd = new HospedagemDAOImpl(connection);
						HospedagemController hc = new HospedagemController(hd);
						Hospedagem hospedagemEncontrada = hc.pesquisarPorId(codHospedagem);
						if (hospedagemEncontrada != null) {
							txtDataInicio.setText(hospedagemEncontrada.getDataInicio().toString());
							txtDataFim.setText(hospedagemEncontrada.getDataFim().toString());
							txtQuantidade.setText(String.valueOf(hospedagemEncontrada.getQtdPessoas()));
							cbxChale.setSelectedItem(hospedagemEncontrada.getCodChale());
							cbxCliente.setSelectedItem(hospedagemEncontrada.getCodCliente());
							cbxEstado.setSelectedItem(hospedagemEncontrada.getEstado());
							lblMensagem.setText("Hospedagem encontrada e campos preenchidos.");
						} else {
							lblMensagem.setText("Hospedagem não encontrada.");
						}
					} catch (NumberFormatException ex) {
						lblMensagem.setText("Código inválido para pesquisa.");
					}
				} else {
					lblMensagem.setText("Preencha o código da hospedagem para pesquisar.");
				}
			}
		});

		JButton btnPesquisar_2 = new JButton("PESQUISAR");
		btnPesquisar_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
				int i = 0;
				for (Hospedagem obj : listaHosp) {
					tbm.addRow(new Object[4]);
					tblConsulta.setValueAt(obj.getCodHospedagem(), i, 0);
					tblConsulta.setValueAt(obj.getEstado(), i, 1);
					tblConsulta.setValueAt(obj.getDataInicio(), i, 2);
					tblConsulta.setValueAt(obj.getDataFim(), i, 3);
					tblConsulta.setValueAt(obj.getQtdPessoas(), i, 4);
					tblConsulta.setValueAt(obj.getCodChale(), i, 5);
					tblConsulta.setValueAt(obj.getCodCliente(), i, 6);
					i++;
				}
			}
		});

		JButton btnLimpar = new JButton("LIMPAR");
		btnLimpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtCod.setText("");
				txtDataInicio.setText("");
				txtDataFim.setText("");
				txtQuantidade.setText("");
				cbxEstado.setSelectedItem(null);
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
			}
		});

		JButton btnSair_1 = new JButton("SAIR");
		btnSair_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmHospedagem.this.dispose();
			}
		});
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE)
						.addGap(6).addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
						.addGap(6).addComponent(btnExcluir, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
						.addGap(6)
						.addComponent(btnPesquisar, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnPesquisar_2, GroupLayout.PREFERRED_SIZE, 118, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnLimpar, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE).addGap(6)
						.addComponent(btnSair_1, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING).addGroup(gl_panel_1
				.createSequentialGroup()
				.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING).addGroup(gl_panel_1.createSequentialGroup()
						.addGap(21)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_1.createSequentialGroup().addGap(21).addComponent(btnNewButton))
								.addGroup(gl_panel_1.createSequentialGroup().addGap(21).addComponent(btnAlterar))
								.addGroup(gl_panel_1.createSequentialGroup().addGap(21).addComponent(btnExcluir))
								.addGroup(gl_panel_1.createSequentialGroup().addGap(21).addComponent(btnPesquisar))
								.addGroup(gl_panel_1.createSequentialGroup().addGap(21).addComponent(btnLimpar))
								.addGroup(gl_panel_1.createSequentialGroup().addGap(21).addComponent(btnSair_1))))
						.addGroup(gl_panel_1.createSequentialGroup().addGap(42).addComponent(btnPesquisar_2)))
				.addContainerGap(16, Short.MAX_VALUE)));
		panel_1.setLayout(gl_panel_1);

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 684, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(14, Short.MAX_VALUE)));
		gl_panel_2.setVerticalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 241, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		tblConsulta = new JTable();
		tblConsulta.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "codHospedagem", "Estado",
				"dataInicio", "dataFim", "qtdPessoas", "codChale", "codCliente" }) {
			Class[] columnTypes = new Class[] { Integer.class, String.class, String.class, String.class, String.class,
					Integer.class, Integer.class };

			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false, false, false, false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tblConsulta.getColumnModel().getColumn(0).setResizable(false);
		tblConsulta.getColumnModel().getColumn(1).setResizable(false);
		tblConsulta.getColumnModel().getColumn(2).setResizable(false);
		tblConsulta.getColumnModel().getColumn(3).setResizable(false);
		tblConsulta.getColumnModel().getColumn(4).setResizable(false);
		tblConsulta.getColumnModel().getColumn(5).setResizable(false);
		tblConsulta.getColumnModel().getColumn(6).setResizable(false);
		scrollPane.setViewportView(tblConsulta);
		panel_2.setLayout(gl_panel_2);
		contentPane.setLayout(gl_contentPane);
	}
}

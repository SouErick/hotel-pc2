package com.pc2.hotel.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.text.ParseException;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import com.pc2.hotel.controller.ClienteController;
import com.pc2.hotel.controller.EnderecoController;
import com.pc2.hotel.model.Cliente;
import com.pc2.hotel.model.Endereco;
import com.pc2.hotel.persistence.ClienteDAO;
import com.pc2.hotel.persistence.ConnectorDB;
import com.pc2.hotel.persistence.EnderecoDAO;
import com.pc2.hotel.persistence.impl.ClienteDAOImpl;
import com.pc2.hotel.persistence.impl.EnderecoDAOImpl;

public class FrmEndereco extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblConsulta;
	private JTextField txtCod;
	private JTextField txtEndereco;
	private JTextField txtCEP;
	private JTextField txtBairro;
	private JLabel lblMensagem = new JLabel("Mensagem");
	private JComboBox cbxEstado;
	private Connection connection = ConnectorDB.connect();
	private MaskFormatter mascaraCEP = null;
	private EnderecoDAO ed = new EnderecoDAOImpl(connection);
	private EnderecoController ec = new EnderecoController(ed);
	private ClienteDAO cd = new ClienteDAOImpl(connection);
	private ClienteController cc = new ClienteController(cd);
	private List<Endereco> listaEnd = ec.listarTodos();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmEndereco frame = new FrmEndereco();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmEndereco() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 830, 665);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		JPanel panel = new JPanel();

		JPanel panel_1 = new JPanel();

		JPanel panel_2 = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 796, Short.MAX_VALUE)
						.addComponent(panel_1, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 796, Short.MAX_VALUE)
						.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 796, Short.MAX_VALUE))
				.addContainerGap()));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
				.createSequentialGroup().addComponent(panel, GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE).addGap(18)
				.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(ComponentPlacement.UNRELATED)
				.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 232, GroupLayout.PREFERRED_SIZE).addGap(9)));

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE).addContainerGap()));
		gl_panel_2.setVerticalGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup().addContainerGap()
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE).addContainerGap()));
		List<Cliente> listaCliente = cc.listarTodosClientes();
		JComboBox<Integer> cbxEndereco = new JComboBox<>();
		for (Cliente obj : listaCliente) {
			cbxEndereco.addItem(obj.getCodCliente());
		}
		tblConsulta = new JTable();
		tblConsulta.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "codEndereco", "enderecoCliente",
				"bairroCliente", "estadoCliente", "CEPCliente", "codCliente" }) {
			Class[] columnTypes = new Class[] { Integer.class, String.class, String.class, String.class, String.class,
					Integer.class };

			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false, false, false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tblConsulta.getColumnModel().getColumn(0).setResizable(false);
		tblConsulta.getColumnModel().getColumn(1).setResizable(false);
		tblConsulta.getColumnModel().getColumn(2).setResizable(false);
		tblConsulta.getColumnModel().getColumn(3).setResizable(false);
		tblConsulta.getColumnModel().getColumn(4).setResizable(false);
		tblConsulta.getColumnModel().getColumn(5).setResizable(false);
		scrollPane.setViewportView(tblConsulta);
		panel_2.setLayout(gl_panel_2);

		JButton btnNewButton = new JButton("INSERIR");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Integer codClienteSelecionado = (Integer) cbxEndereco.getSelectedItem();
				Endereco endereco = new Endereco();
				endereco.setCodCliente(codClienteSelecionado); 
				endereco.setEnderecoCliente(txtEndereco.getText()); 
				endereco.setBairroCliente(txtBairro.getText()); 
				endereco.setEstadoCliente((String) cbxEstado.getSelectedItem()); 
				endereco.setCepCliente(txtCEP.getText()); 
				String mensagem = ec.inserir(endereco);
				lblMensagem.setText(mensagem);
			}
		});

		JButton btnAlterar = new JButton("ALTERAR");
		btnAlterar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!txtCod.getText().isEmpty()) {
					try {
						int codEndereco = Integer.parseInt(txtCod.getText());
						Endereco enderecoExistente = listaEnd.stream()
								.filter(end -> end.getCodEndereco() == codEndereco).findFirst().orElse(null);
						if (enderecoExistente != null) {
							enderecoExistente.setEnderecoCliente(txtEndereco.getText());
							enderecoExistente.setBairroCliente(txtBairro.getText());
							enderecoExistente.setEstadoCliente((String) cbxEstado.getSelectedItem());
							enderecoExistente.setCepCliente(txtCEP.getText());
							Integer codClienteSelecionado = (Integer) cbxEndereco.getSelectedItem();
							enderecoExistente.setCodCliente(codClienteSelecionado);
							String mensagem = ec.alterar(enderecoExistente);
							lblMensagem.setText(mensagem);
							listaEnd = ec.listarTodos();
						} else {
							lblMensagem.setText("Endereço não encontrado para alteração.");
						}
					} catch (NumberFormatException ex) {
						lblMensagem.setText("Código inválido para alteração.");
					}
				} else {
					lblMensagem.setText("Preencha o código do endereço para alterar.");
				}
			}
		});

		JButton btnExcluir = new JButton("EXCLUIR");
		btnExcluir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		        if (txtCod.getText().isEmpty()) {
		            lblMensagem.setText("Preencha o código do endereço.");
		            return;
		        }
		        EnderecoDAO ed = new EnderecoDAOImpl(connection);
		        EnderecoController ec = new EnderecoController(ed);
		        try {
		            Endereco endereco = new Endereco();
		            endereco.setCodEndereco(Integer.parseInt(txtCod.getText()));
		            Object[] opcoes = { "Sim", "Não" };
		            int i = JOptionPane.showOptionDialog(null,
		                    "Deseja excluir esse Endereço com o código: " + txtCod.getText() + "?",
		                    "Exclusão",
		                    JOptionPane.YES_NO_OPTION,
		                    JOptionPane.QUESTION_MESSAGE,
		                    null,
		                    opcoes,
		                    opcoes[0]);

		            if (JOptionPane.YES_OPTION == i) {
		                String mensagem = ec.excluir(endereco);
		                lblMensagem.setText(mensagem);
		            }
		        } catch (NumberFormatException ex) {
		            lblMensagem.setText("Código inválido.");
		        } catch (Exception ex) {
		            lblMensagem.setText("Erro ao excluir endereço: " + ex.getMessage());
		        }
			}
		});
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});

		JButton btnPesquisar = new JButton("PESQUISAR POR COD");
		btnPesquisar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!txtCod.getText().isEmpty()) {
					try {
						int codEndereco = Integer.parseInt(txtCod.getText());
						Endereco enderecoEncontrado = listaEnd.stream()
								.filter(end -> end.getCodEndereco() == codEndereco).findFirst().orElse(null);
						if (enderecoEncontrado != null) {
							txtEndereco.setText(enderecoEncontrado.getEnderecoCliente());
							txtBairro.setText(enderecoEncontrado.getBairroCliente());
							cbxEstado.setSelectedItem(enderecoEncontrado.getEstadoCliente());
							txtCEP.setText(enderecoEncontrado.getCepCliente());
							cbxEndereco.setSelectedItem(enderecoEncontrado.getCodCliente());

							lblMensagem.setText("Endereço encontrado e campos preenchidos.");
						} else {
							lblMensagem.setText("Endereço não encontrado.");
						}
					} catch (NumberFormatException ex) {
						lblMensagem.setText("Código inválido para pesquisa.");
					}
				} else {
					lblMensagem.setText("Preencha o código do endereço para pesquisar.");
				}
			}
		});

		JButton btnPesquisar_2 = new JButton("PESQUISAR");
		btnPesquisar_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
				int i = 0;
				for (Endereco obj : listaEnd) {
					tbm.addRow(new Object[4]);
					tblConsulta.setValueAt(obj.getCodEndereco(), i, 0);
					tblConsulta.setValueAt(obj.getEnderecoCliente(), i, 1);
					tblConsulta.setValueAt(obj.getBairroCliente(), i, 2);
					tblConsulta.setValueAt(obj.getEstadoCliente(), i, 3);
					tblConsulta.setValueAt(obj.getCepCliente(), i, 4);
					tblConsulta.setValueAt(obj.getCodCliente(), i, 5);
					i++;
				}
			}
		});

		JButton btnLimpar = new JButton("LIMPAR");
		btnLimpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBairro.setText("");
				txtCEP.setText("");
				txtCod.setText("");
				txtEndereco.setText("");
				cbxEndereco.setSelectedItem(null);
				DefaultTableModel tbm = (DefaultTableModel) tblConsulta.getModel();
				for (int i = tbm.getRowCount() - 1; i >= 0; i--) {
					tbm.removeRow(i);
				}
			}
		});

		JButton btnSair = new JButton("SAIR");

		JButton btnSair_1 = new JButton("SAIR");
		btnSair_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmEndereco.this.dispose();
			}
		});
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addContainerGap()
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnExcluir, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnPesquisar, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED).addComponent(btnPesquisar_2).addGap(18)
						.addComponent(btnLimpar, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnSair_1, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE).addGap(65)
						.addComponent(btnSair, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING).addGroup(gl_panel_1
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING).addComponent(btnAlterar)
						.addComponent(btnPesquisar).addComponent(btnNewButton).addComponent(btnExcluir)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE).addComponent(btnPesquisar_2)
								.addComponent(btnLimpar).addComponent(btnSair_1))
						.addComponent(btnSair))
				.addContainerGap(25, Short.MAX_VALUE)));
		panel_1.setLayout(gl_panel_1);

		JLabel lblNewLabel = new JLabel("Cliente: ");

		JLabel lblNewLabel_1 = new JLabel("Codigo: ");

		JLabel lblNewLabel_2 = new JLabel("Endereço: ");

		JLabel lblNewLabel_3 = new JLabel("Bairro: ");

		JLabel lblNewLabel_5 = new JLabel("Estado");

		JLabel lblNewLabel_6 = new JLabel("CEP: ");

		lblMensagem.setForeground(new Color(0, 128, 255));

		ClienteDAO cd = new ClienteDAOImpl(connection);
		ClienteController cc = new ClienteController(cd);

		txtCod = new JTextField();
		txtCod.setColumns(10);

		txtEndereco = new JTextField();
		txtEndereco.setColumns(10);

		try {
			mascaraCEP = new MaskFormatter("########");
		} catch (ParseException e) {
			System.err.println(e.getMessage());
		}
		txtCEP = new JFormattedTextField(mascaraCEP);
		txtCEP.setColumns(10);

		txtBairro = new JTextField();
		txtBairro.setColumns(10);

		cbxEstado = new JComboBox();
		cbxEstado.setModel(new DefaultComboBoxModel(new String[] {"", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"}));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblMensagem, GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
						.addGroup(gl_panel.createSequentialGroup().addGroup(gl_panel
								.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lblNewLabel_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lblNewLabel_6, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
												GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_5, Alignment.LEADING)))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false).addComponent(txtBairro)
										.addComponent(txtEndereco).addComponent(txtCod)
										.addComponent(cbxEndereco, 0, 620, Short.MAX_VALUE)
										.addComponent(cbxEstado, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(txtCEP))
								.addPreferredGap(ComponentPlacement.RELATED, 102, Short.MAX_VALUE)))
				.addContainerGap()));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(gl_panel
				.createSequentialGroup().addContainerGap()
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel).addComponent(
						cbxEndereco, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_1).addComponent(
						txtCod, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_2).addComponent(
						txtEndereco, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING).addComponent(lblNewLabel_3).addComponent(
						txtBairro, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_5).addComponent(
						cbxEstado, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE).addComponent(lblNewLabel_6).addComponent(
						txtCEP, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addGap(43).addComponent(lblMensagem).addContainerGap(81, Short.MAX_VALUE)));
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
	}
}

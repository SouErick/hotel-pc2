/* Aluno: Erick Sousa Saraiva */
package com.pc2.hotel;

import java.sql.Connection;

import com.pc2.hotel.controller.ChaleController;
import com.pc2.hotel.controller.ChaleItemController;
import com.pc2.hotel.controller.ClienteController;
import com.pc2.hotel.controller.EnderecoController;
import com.pc2.hotel.controller.HospedagemController;
import com.pc2.hotel.controller.HospedagemServicoController;
import com.pc2.hotel.controller.ItemController;
import com.pc2.hotel.controller.ServicoController;
import com.pc2.hotel.controller.TelefoneController;
import com.pc2.hotel.persistence.ChaleDAO;
import com.pc2.hotel.persistence.ChaleItemDAO;
import com.pc2.hotel.persistence.ClienteDAO;
import com.pc2.hotel.persistence.ConnectorDB;
import com.pc2.hotel.persistence.EnderecoDAO;
import com.pc2.hotel.persistence.HospedagemDAO;
import com.pc2.hotel.persistence.HospedagemServicoDAO;
import com.pc2.hotel.persistence.ItemDAO;
import com.pc2.hotel.persistence.ServicoDAO;
import com.pc2.hotel.persistence.TelefoneDAO;
import com.pc2.hotel.persistence.impl.ChaleDAOImpl;
import com.pc2.hotel.persistence.impl.ChaleItemDAOImpl;
import com.pc2.hotel.persistence.impl.ClienteDAOImpl;
import com.pc2.hotel.persistence.impl.EnderecoDAOImpl;
import com.pc2.hotel.persistence.impl.HospedagemDAOImpl;
import com.pc2.hotel.persistence.impl.HospedagemServicoDAOImpl;
import com.pc2.hotel.persistence.impl.ItemDAOImpl;
import com.pc2.hotel.persistence.impl.ServicoDAOImpl;
import com.pc2.hotel.persistence.impl.TelefoneDAOImpl;

public class Main {
    public static void main(String[] args) {
        Connection connection = null;
        try {
            connection = ConnectorDB.connect();
            if (connection != null) {
                System.out.println("Conexão estabelecida com sucesso!");
                ChaleDAO chaleDAO = new ChaleDAOImpl(connection);
                ChaleItemDAO chaleItemDAO = new ChaleItemDAOImpl(connection);
                ClienteDAO clienteDAO = new ClienteDAOImpl(connection);
                EnderecoDAO enderecoDAO = new EnderecoDAOImpl(connection);
                HospedagemDAO hospedagemDAO = new HospedagemDAOImpl(connection);
                HospedagemServicoDAO hospedagemServicoDAO = new HospedagemServicoDAOImpl(connection);
                ItemDAO itemDAO = new ItemDAOImpl(connection);
                ServicoDAO servicoDAO = new ServicoDAOImpl(connection);
                TelefoneDAO telefoneDAO = new TelefoneDAOImpl(connection);
                ChaleController chaleController = new ChaleController(chaleDAO);
                ChaleItemController chaleItemController = new ChaleItemController(chaleItemDAO);
                ClienteController clienteController = new ClienteController(clienteDAO);
                EnderecoController enderecoController = new EnderecoController(enderecoDAO);
                HospedagemController hospedagemController = new HospedagemController(hospedagemDAO);
                HospedagemServicoController hospedagemServicoController = new HospedagemServicoController(hospedagemServicoDAO);
                ItemController itemController = new ItemController(itemDAO);
                ServicoController servicoController = new ServicoController(servicoDAO);
                TelefoneController telefoneController = new TelefoneController(telefoneDAO);
            } else {
                System.out.println("Falha ao estabelecer a conexão.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                ConnectorDB.close(connection);
            }
        }
    }
}
